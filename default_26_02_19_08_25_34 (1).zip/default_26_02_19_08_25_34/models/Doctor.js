const mongoose = require('mongoose');

const doctorSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Doctor name is required'],
    },
    specialty: {
      type: String,
      required: [true, 'Specialty is required'],
    },
    experience: {
      type: Number,
      required: [true, 'Years of experience is required'],
    },
    bio: {
      type: String,
      required: [true, 'Bio is required'],
    },
    image: {
      type: String,
      default: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=400',
    },
    fees: {
      type: Number,
      required: [true, 'Consultation fees is required'],
    },
    availability: {
      type: [String],
      required: [true, 'Availability slots are required'],
      default: ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM'],
    },
  },
  {
    timestamps: true,
  }
);

const Doctor = mongoose.model('Doctor', doctorSchema);

module.exports = Doctor;
