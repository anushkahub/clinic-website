# Clinic Website Backend

A complete production-ready backend for a Clinic Management System, built with Node.js, Express, and MongoDB.

## Features

- **User Management**: Registration and login for patients and admins with JWT authentication.
- **Doctor Directory**: Manage doctor profiles, specialties, fees, and availability.
- **Appointment Booking**: Patients can book slots; admins can manage and update statuses.
- **Contact Inquiries**: Public contact form submissions and admin review dashboard.
- **Security**: Password hashing with bcrypt, protected routes via JWT, and CORS enabled.
- **Error Handling**: Custom centralized error handling middleware.

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (Local installation or MongoDB Atlas Cloud)
- npm or yarn

## Installation

1. Clone the repository or extract the files.
2. Navigate to the project directory:
    cd clinic-backend
3. Install dependencies:
    npm install

## Configuration

1. Create a `.env` file in the root directory (or use the provided one).
2. Set the following environment variables:
    PORT=5000
    MONGO_URI=your_mongodb_connection_string
    JWT_SECRET=your_jwt_secret_key
    NODE_ENV=development

## Running the Application

To start the server in production mode:
    npm start

To start the server in development mode (with auto-reload):
    npm run dev

The API will be accessible at `http://localhost:5000`.

## API Endpoints

### Auth / Users
- `POST /api/users/register` - Register a new patient
- `POST /api/users/login` - Login and get token
- `GET /api/users/profile` - Get current user profile (Protected)

### Doctors
- `GET /api/doctors` - Get all doctors
- `GET /api/doctors/:id` - Get specific doctor details
- `POST /api/doctors` - Add new doctor (Admin only)

### Appointments
- `POST /api/appointments` - Book an appointment (Protected)
- `GET /api/appointments/my` - Get current user's appointments (Protected)
- `PUT /api/appointments/:id` - Update appointment status (Admin only)

### Contact
- `POST /api/contact` - Submit a contact message (Public)
- `GET /api/contact` - Get all contact inquiries (Admin only)

## Project Structure

    clinic-backend/
    ├── config/           # Database configuration
    ├── controllers/      # Route controllers (logic)
    ├── middleware/       # Custom auth & error middlewares
    ├── models/           # Mongoose schemas
    ├── routes/           # Express route definitions
    ├── utils/            # Helper functions (token gen)
    ├── .env              # Environment variables
    ├── server.js         # Entry point
    └── package.json      # Dependencies and scripts

## Troubleshooting

- **MongoDB Connection Error**: Ensure your `MONGO_URI` is correct and your IP is whitelisted if using MongoDB Atlas.
- **JWT Secret**: Ensure `JWT_SECRET` is defined in `.env` to avoid signature errors.
- **Port Conflict**: If 5000 is occupied, change the `PORT` in `.env`.
