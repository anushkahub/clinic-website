const express = require('express');
const router = express.Router();
const {
  getDoctors,
  getDoctorById,
  addDoctor,
} = require('../controllers/doctorController');
const { protect, admin } = require('../middleware/authMiddleware');

router.get('/', getDoctors);
router.get('/:id', getDoctorById);
router.post('/', protect, admin, addDoctor);

module.exports = router;
