const express = require('express');
const router = express.Router();
const {
  submitContactForm,
  getInquiries,
} = require('../controllers/contactController');
const { protect, admin } = require('../middleware/authMiddleware');

router.post('/', submitContactForm);
router.get('/', protect, admin, getInquiries);

module.exports = router;
