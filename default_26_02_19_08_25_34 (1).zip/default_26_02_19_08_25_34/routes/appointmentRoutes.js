const express = require('express');
const router = express.Router();
const {
  bookAppointment,
  getMyAppointments,
  updateAppointmentStatus,
} = require('../controllers/appointmentController');
const { protect, admin } = require('../middleware/authMiddleware');

router.post('/', protect, bookAppointment);
router.get('/my', protect, getMyAppointments);
router.put('/:id', protect, admin, updateAppointmentStatus);

module.exports = router;
