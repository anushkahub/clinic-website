const Doctor = require('../models/Doctor');

// @desc    Fetch all doctors
// @route   GET /api/doctors
// @access  Public
const getDoctors = async (req, res) => {
  try {
    const doctors = await Doctor.find({});
    res.json(doctors);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Fetch single doctor
// @route   GET /api/doctors/:id
// @access  Public
const getDoctorById = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id);

    if (doctor) {
      res.json(doctor);
    } else {
      res.status(404).json({ message: 'Doctor not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Add a new doctor
// @route   POST /api/doctors
// @access  Private/Admin
const addDoctor = async (req, res) => {
  const { name, specialty, experience, bio, image, fees, availability } = req.body;

  try {
    const doctor = new Doctor({
      name,
      specialty,
      experience,
      bio,
      image,
      fees,
      availability,
    });

    const createdDoctor = await doctor.save();
    res.status(201).json(createdDoctor);
  } catch (error) {
    res.status(400).json({ message: 'Invalid doctor data', error: error.message });
  }
};

module.exports = {
  getDoctors,
  getDoctorById,
  addDoctor,
};
