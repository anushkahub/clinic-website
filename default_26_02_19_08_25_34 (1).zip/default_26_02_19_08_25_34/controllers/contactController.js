const Contact = require('../models/Contact');

// @desc    Submit contact form
// @route   POST /api/contact
// @access  Public
const submitContactForm = async (req, res) => {
  const { fullName, email, subject, message } = req.body;

  try {
    const contact = await Contact.create({
      fullName,
      email,
      subject,
      message,
    });

    if (contact) {
      res.status(201).json({ message: 'Inquiry submitted successfully' });
    }
  } catch (error) {
    res.status(400).json({ message: 'Submission failed', error: error.message });
  }
};

// @desc    Get all inquiries
// @route   GET /api/contact
// @access  Private/Admin
const getInquiries = async (req, res) => {
  try {
    const inquiries = await Contact.find({}).sort({ createdAt: -1 });
    res.json(inquiries);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

module.exports = {
  submitContactForm,
  getInquiries,
};
